# Arria Visuals — Portfolio Website

## Folder Structure

```
arria-visuals/
├── index.html              ← your website
├── js/
│   └── photos.js           ← YOUR PHOTO CONTROL PANEL (edit this to add photos)
├── images/
│   ├── hero/               ← hero background photo
│   ├── favorites/          ← "My Favorites" section (homepage)
│   ├── portraiture/
│   │   ├── senior-portraits/
│   │   ├── natural-light/
│   │   ├── studio-series/
│   │   └── street-faces/
│   ├── nature/
│   │   ├── desert-light/
│   │   ├── monsoon-season/
│   │   ├── mountain-trails/
│   │   └── golden-hour/
│   ├── sports/
│   │   ├── brophy-football/
│   │   ├── arcadia-baseball/
│   │   ├── track-field/
│   │   └── basketball/
│   └── events/
│       ├── little-league-opening/
│       ├── arcadia-hs-grad/
│       ├── community-fest/
│       └── awards-night/
└── README.md
```

---

## How to Add a Photo (takes ~1 minute)

1. **Drop the photo** into the right folder under `images/`
2. **Open `js/photos.js`** and find the matching section
3. **Add one line** to the `photos` array:
   ```js
   { src: "my-new-photo.jpg", alt: "Game-winning shot" },
   ```
4. **Commit and push** to GitHub — site updates instantly

That's it. No touching `index.html` ever.

---

## How to Add a New Project

Example: adding a new sports project called "Soccer 2025"

1. Create the folder: `images/sports/soccer-2025/`
2. Add your photos there
3. In `photos.js`, add a new entry inside `sports: { ... }`:
   ```js
   "soccer-2025": {
     title: "Soccer 2025",
     year: "2025",
     cover: "soccer-1.jpg",
     photos: [
       { src: "soccer-1.jpg", alt: "Soccer match 1" },
       { src: "soccer-2.jpg", alt: "Soccer match 2" },
     ],
   },
   ```
4. Push — it appears automatically on the Sports landing page.

---

## GitHub Setup (first time only)

### Step 1 — Create the repo
1. Go to [github.com](https://github.com) → click **New repository**
2. Name it `arria-visuals` (or anything you want)
3. Set it to **Public**
4. Click **Create repository**

### Step 2 — Upload your files
**Option A — GitHub Desktop (easiest):**
1. Download [GitHub Desktop](https://desktop.github.com)
2. File → Add Local Repository → select this folder
3. Commit and push

**Option B — Drag and drop on GitHub.com:**
1. Open your new repo on github.com
2. Drag your entire project folder into the browser

### Step 3 — Enable GitHub Pages
1. In your repo → **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: **main** / root
4. Click **Save**
5. Wait ~1 minute → your site is live at `https://yourusername.github.io/arria-visuals`

### Step 4 — Adding photos going forward
Every time you add photos:
1. Drop photos in the right `images/` subfolder
2. Update `js/photos.js`
3. GitHub Desktop → write a commit message → **Push origin**
4. Site updates within 30 seconds

---

## Photo Tips
- **Format:** `.jpg` or `.webp` recommended (smaller file size, fast load)
- **Size:** Export at 1200px on the long side — enough quality, fast enough to load
- **Naming:** lowercase, hyphens not spaces (e.g. `brophy-game-1.jpg` not `Brophy Game 1.jpg`)
- **Cover image:** The first photo listed in each project's `photos` array is used as the cover card
